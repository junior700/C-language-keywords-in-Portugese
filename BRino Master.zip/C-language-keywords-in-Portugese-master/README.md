# C-language-keywords-in-Portugese
This is an Arduino software library to translate C language keywords to Portuguese
Em 08/05/2018
We include difinitions like BRino (http://brino.cc/sobre)

