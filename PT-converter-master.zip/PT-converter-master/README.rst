PTconverter Library for Arduino
==============

This is an Arduino software library to translate C language keywords to Portuguese

Copyright (c) 2017 Helio R. de Freitas Jr.  
All rights reserved.

This software is released under an MIT license. See the attached LICENSE file for details.
